
    function linkHighlight()
	{
        src = event.toElement;
        if (src.tagName == "A")
		{
            src.oldColor = src.style.color;
			src.oldTextDecoration = src.style.textDecoration;

			src.style.color = "#FF0000";
			src.style.textDecoration = "underline";
        }
    }

    function linkNormal()
	{
        src = event.fromElement;
        if (src.tagName == "A")
		{
            src.style.color = src.oldColor;
			src.style.textDecoration = src.oldTextDecoration;
		}
    }
	//-----------------------------------------------------------------------------------
	// function changeFolder(srcElement,targetElement);
	//
	// Change the folder image in the outline, and collapses or expands
	// the outline.  Uses Dynamic HTML (IE4 only)
	//-----------------------------------------------------------------------------------
	function changeFolder(srcElement,targetElement)
	{
		var targetElement,targetID;

		if (ie>=4)  //Nav will give an error for the document.all() thing.
		{
			targetID=srcElement.id + "D";
			targetElement = document.all(targetID);

			if (targetElement.style.display == "none")
			{
				targetElement.style.display = "";
				srcElement.src = folderImages[1].src;
			}
			else
			{
				targetElement.style.display = "none";
				srcElement.src = folderImages[0].src;
			}
		}
	}

	//-----------------------------------------------------------------------------------
	// function changeImage(image, type);
	//
	// Change the image in the navigation bar.  First number is the image number,
	// second number is the type (0=normal, 1=button, 2=pressed button)
	// Images are loaded in init(); below.
	//-----------------------------------------------------------------------------------
	function changeImage(image, type)
	{
		if ((nav>=3 && ie==0) || ie>=4)
		{
			if (image==0) document.prev.src = navImages[image*3+type].src;
			else if (image==1) document.home.src = navImages[image*3+type].src;
			else if (image==2) document.next.src = navImages[image*3+type].src;
		}
	}
	
	//-----------------------------------------------------------------------------------
	// function ieVersion();
	//
	// I got this one from a .hlp file from Microsoft's site.
	// Returns Microsoft Internet Explorer (major) version number, or 0 for others
	//-----------------------------------------------------------------------------------
	function ieVersion()
	{
		var ua = window.navigator.userAgent;
		var msie = ua.indexOf("MSIE ");
		if (msie>=0)	
			return parseInt ( ua.substring ( msie+5, ua.indexOf ( ".", msie ) ) );
		else
			return 0;	
	}

	//-----------------------------------------------------------------------------------
	// function navVersion();
	//
	// Returns Netscape Navigator (major) version number, or 0 for others
	//-----------------------------------------------------------------------------------
	function navVersion()
	{
		var ua = window.navigator.userAgent;
		var nav = ua.indexOf ( "Mozilla/" );
		if (nav>=0)
			return parseInt ( ua.substring ( nav+8, ua.indexOf (".") ) );
		else
			return 0;	// is other browser
	}

	//-----------------------------------------------------------------------------------
	// Startup code
	//
	// Load all of the images into two global arrays,
	// "navImages" and "folderImages".  
	// (This puts the images in the browser's cache. Yay!)
	//-----------------------------------------------------------------------------------
			
	ie = ieVersion();
	nav = navVersion();
	
	if ((nav>=3 && ie==0) || ie>=4)
	{
		var i;
		navImages = new Array(9);
		folderImages= new Array(2);

		for(i=0;i<3;i++)
		{
			navImages[i]       = new Image();
			navImages[i].src   = "images/prev"+i+".gif";
			navImages[i+3]     = new Image();
			navImages[i+3].src = "images/home"+i+".gif";
			navImages[i+6]     = new Image();
			navImages[i+6].src = "images/next"+i+".gif";
		}
		for(i=0;i<2;i++)
		{
			folderImages[i]     = new Image();
			folderImages[i].src = "images/folder"+i+".gif";
		}
	}

    if (ie>=4)
	{
        document.body.onmouseover=linkHighlight;
        document.body.onmouseout=linkNormal;
    }

