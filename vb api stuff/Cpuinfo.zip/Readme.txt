Techniques demonstrated in this project
---------------------------------------
-Calling functions in a 3rd party DLL function library
-Working with register-level "packed bitfields"
-Handling a 64bit integer by using a currency type to receive the
value and then using RTLMoveMemory() to transfer it to 2 long types


Useful functions in CPUInf32.bas
--------------------------------
wincpuidsupport()
processorcount()
cpunormspeed()
cpurawspeed()
getCPUDescription()
getcpudescriptionString()
getcpumodel()
getcputype()
wincpuid()/getcpufamily()
CPUhasMMX()
CPUhasFPU()
CPUHasTimeStampCounter()
GetTimeStampCode()
GetDllVerString()
GetBit()

You may freely use and modify this code in your 
own programs.  However, you may not redistribute 
this sample without permission from Ray Mercer 
<raymer@macnica.co.jp>

Copyright (c) 1998, Ray Mercer all rights reserved