INSTALLATION

STEP ONE:

If you do not have Visual Basic 5.0 installed then you will need to download the 1 MB file SUPPORT.ZIP which contains all the necessary support files.  Unzip this file in your C:\WINDOWS\SYSTEM directory.


STEP TWO:

If you have Visual Basic 5.0 installed or have completed step one, then you just need to unzip MIKOUTIL.ZIP into your C:\WINDOWS\SYSTEM directory and run the file REGISTER.BAT.  This will use the file REGOCX32.EXE to automatically register these controls.


